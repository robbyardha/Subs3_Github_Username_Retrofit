package com.ardhacodes.github_retro

data class GithubRepositoryResponse(
    val items : ArrayList<GithubRepos>
)
