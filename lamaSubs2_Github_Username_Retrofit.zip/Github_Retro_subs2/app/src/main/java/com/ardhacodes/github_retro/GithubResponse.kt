package com.ardhacodes.github_retro

data class GithubResponse(
    val items : ArrayList<Githubuser>
)
