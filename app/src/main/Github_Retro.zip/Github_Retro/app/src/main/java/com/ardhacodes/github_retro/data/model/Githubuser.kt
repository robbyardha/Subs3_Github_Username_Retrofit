package com.ardhacodes.github_retro.data.model

data class Githubuser(
    val login : String,
    val id : Int,
    val avatar_url : String,
    val name : String,

)
