package com.ardhacodes.github_retro.user_interface.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.ardhacodes.github_retro.R
import com.ardhacodes.github_retro.databinding.ActivityDetailUserBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

class DetailUserActivity : AppCompatActivity() {

    companion object{
        const val EXTRA_USERNAME =  "extra_username"
    }

    private lateinit var binding: ActivityDetailUserBinding

    private lateinit var viewModel: DetailUserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)

        setContentView(binding.root)

        val username = intent.getStringExtra(EXTRA_USERNAME)

        //bundle fragment
        val bundle = Bundle()
        bundle.putString(EXTRA_USERNAME, username)

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailUserViewModel::class.java)
        viewModel.setUserDetail(username!!)
        viewModel.getUserDetail().observe(this, {
            if (it != null){
                binding.apply {
                    tvUsername.text = it.login.toString()
                    tvNama.text = it.name.toString()
                    tvCompany.text = it.company.toString()
                    tvLocation.text = it.location.toString()
                    tvFollowers.text = "Followers: ${it.followers}"
                    tvFollowing.text = "Following: ${it.following}"
                    tvRepository.text = "Repository: ${it.public_repos}"
                    Glide.with(this@DetailUserActivity)
                        .load(it.avatar_url)
                        .centerCrop()
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .into(circleAvatarDetail)
                }
            }
        })

        val sectionPagerAdapter = SectionPagerAdapter(this, supportFragmentManager, bundle)
        binding.apply {
            viewPager.adapter = sectionPagerAdapter
            clicktabs.setupWithViewPager(viewPager)
        }
    }
}