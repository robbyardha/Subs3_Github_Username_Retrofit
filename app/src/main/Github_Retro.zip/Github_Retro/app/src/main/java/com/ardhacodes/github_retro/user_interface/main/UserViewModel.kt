package com.ardhacodes.github_retro.user_interface.main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ardhacodes.github_retro.API.Client
import com.ardhacodes.github_retro.data.model.GithubResponse
import com.ardhacodes.github_retro.data.model.Githubuser
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserViewModel : ViewModel() {
    val listuser = MutableLiveData<ArrayList<Githubuser>>()

    fun setSearchUsername(query: String){
         Client.apiInstance
            .getSearchUsers(query)
            .enqueue(object : Callback<GithubResponse>{
                override fun onResponse(
                    call: Call<GithubResponse>,
                    response: Response<GithubResponse>
                ) {
                    if (response.isSuccessful){
                        listuser.postValue(response.body()?.items)
                    }
                }

                override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                    Log.d("failure", t.message.toString())
                }

            })
    }

    fun getSearchUsers() : LiveData<ArrayList<Githubuser>>{
        return listuser
    }

    fun setUsers()
    {
        Client.apiInstance
                .getUsers()
                .enqueue(object : Callback<GithubResponse>{
                    override fun onResponse(call: Call<GithubResponse>, response: Response<GithubResponse>) {
                        if (response.isSuccessful){
                            listuser.postValue(response.body()?.items)
                        }
                    }

                    override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                        Log.d("failure", t.message.toString())
                    }

                })
    }

    fun getUsers() : LiveData<ArrayList<Githubuser>>
    {
        return listuser
    }

}