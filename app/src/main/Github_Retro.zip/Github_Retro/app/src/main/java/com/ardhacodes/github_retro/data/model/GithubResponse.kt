package com.ardhacodes.github_retro.data.model

data class GithubResponse(
    val items : ArrayList<Githubuser>
)
